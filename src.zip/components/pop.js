// css 에 역할을 하는 객체 리터럴은 변수명을 파스칼로 합니다.(관례상)
export const TitleStyle = {
  color: "red",
  fontSize: "12px",
  background: "#eee",
};

export const BodyStyle = {
  color: "green",
  fontSize: "10px",
};
