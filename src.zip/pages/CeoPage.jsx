import Footer from "../components/Footer";
import Header from "../components/header";

function CeoPage() {
  return (
    <>
      <Header />
      <main>대표 인사말</main>
      <Footer />
    </>
  );
}

export default CeoPage;
