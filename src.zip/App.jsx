function App() {
  // const a = 1;
  return <div>App</div>;
}

export default App;
