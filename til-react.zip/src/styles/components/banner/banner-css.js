export const BannerStyleObj = {
  display: "flex",
  backgroundColor: "yellowgreen",
  width: "calc(100% / 3)",
  height: "200px",
  alignItems: "center",
  justifyContent: "center",
};
