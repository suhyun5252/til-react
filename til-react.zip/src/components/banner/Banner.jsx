import { BannerStyleObj } from "../../styles/components/banner/banner-css";

const Banner = () => {
  return <div style={BannerStyleObj}>배너</div>;
};

export default Banner;
