const Notice = () => {
  return (
    <div
      style={{
        display: "flex",
        backgroundColor: "orange",
        width: "calc(100% / 3)",
        height: "200px",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      공지사항
    </div>
  );
};

export default Notice;
